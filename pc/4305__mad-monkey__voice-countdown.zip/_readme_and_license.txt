Sound pack downloaded from Freesound.org
----------------------------------------

This pack of sounds contains sounds by mad-monkey ( http://freesound.org/people/mad-monkey/  )
You can find this pack online at: http://freesound.org/people/mad-monkey/packs/4305/


License details
---------------

Sampling+: http://creativecommons.org/licenses/sampling+/1.0/
Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/
Attribution: http://creativecommons.org/licenses/by/3.0/
Attribution Noncommercial: http://creativecommons.org/licenses/by-nc/3.0/


Sounds in this pack
-------------------

  * 66698__mad_monkey__002.wav
    * url: http://freesound.org/people/mad-monkey/sounds/66698/
    * license: Sampling+
  * 66696__mad_monkey__000.wav
    * url: http://freesound.org/people/mad-monkey/sounds/66696/
    * license: Sampling+
  * 66697__mad_monkey__001.wav
    * url: http://freesound.org/people/mad-monkey/sounds/66697/
    * license: Sampling+
  * 66701__mad_monkey__005.wav
    * url: http://freesound.org/people/mad-monkey/sounds/66701/
    * license: Sampling+
  * 66700__mad_monkey__004.wav
    * url: http://freesound.org/people/mad-monkey/sounds/66700/
    * license: Sampling+
  * 66699__mad_monkey__003.wav
    * url: http://freesound.org/people/mad-monkey/sounds/66699/
    * license: Sampling+
  * 66704__mad_monkey__008.wav
    * url: http://freesound.org/people/mad-monkey/sounds/66704/
    * license: Sampling+
  * 66705__mad_monkey__009.wav
    * url: http://freesound.org/people/mad-monkey/sounds/66705/
    * license: Sampling+
  * 66703__mad_monkey__007.wav
    * url: http://freesound.org/people/mad-monkey/sounds/66703/
    * license: Sampling+
  * 66702__mad_monkey__006.wav
    * url: http://freesound.org/people/mad-monkey/sounds/66702/
    * license: Sampling+
  * 66706__mad_monkey__010.wav
    * url: http://freesound.org/people/mad-monkey/sounds/66706/
    * license: Sampling+

